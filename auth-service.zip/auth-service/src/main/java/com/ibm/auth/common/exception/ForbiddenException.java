package com.ibm.auth.common.exception;

public class ForbiddenException extends RuntimeException{

  public ForbiddenException(String message){
        super(message);
    }
}
